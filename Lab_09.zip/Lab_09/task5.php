<?php
	
	$arr = array("Samreen"=>"31","Jahan"=>"41","Warisha"=>"39","Rania"=>"40");
	print_r($arr);
	asort($arr);
	print_r($arr);
	ksort($arr);
	print_r($arr);
	arsort($arr);
	print_r($arr);
	krsort($arr);
	print_r($arr);
?>